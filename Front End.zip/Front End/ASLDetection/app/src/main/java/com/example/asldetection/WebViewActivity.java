package com.example.asldetection;

import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


public class WebViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        //WebView.setWebContentsDebuggingEnabled(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webview);

        WebView webView = findViewById(R.id.webView);
        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Enable JavaScript
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);


        // Load the URL
        webView.clearCache(true);
        webView.reload();

        webView.loadUrl("http://192.168.8.100:5000/camera_feed_with_predictions");

    }
}
