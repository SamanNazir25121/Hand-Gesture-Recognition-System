package com.example.asldetection;
import static com.example.asldetection.R.color.black;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.core.content.ContextCompat;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("ResourceAsColor")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = findViewById(R.id.imageView);
        imageView.setImageResource(R.drawable.front); // Replace with your image resource

        TextView titleTextView = findViewById(R.id.titleTextView);
        titleTextView.setText("Sign To Text");
        titleTextView.setTextSize(30);
        titleTextView.setTypeface(null, Typeface.BOLD);

        TextView descriptionTextView = findViewById(R.id.descriptionTextView);
        descriptionTextView.setText("App that can convert American sign language to text in real time");
        descriptionTextView.setTextSize(16);
        descriptionTextView.setGravity(Gravity.CENTER);

        Button getStartedButton = findViewById(R.id.getStartedButton);
        getStartedButton.setText("Get Started");
        getStartedButton.setTextSize(20);
        int blueColor = ContextCompat.getColor(this, R.color.blue_clr);
        getStartedButton.setBackgroundColor(blueColor);
        getStartedButton.setTextColor(ContextCompat.getColor(this, android.R.color.holo_blue_light));

        getStartedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Replace 'NextActivity.class' with the name of the Java activity you want to navigate to.
                Intent intent = new Intent(MainActivity.this, SecondActivity.class);
                startActivity(intent);
            }
        });
    }
}
